package farmacia;

public class Farmaceutico extends Funcionario{
	/* Attributes */
	private String registroAnvisa;
	
	/* Getters */
	public String getRegistroAnvisa() {
		return registroAnvisa;
	}
	
	/* Setters */
	public void setRegistroAnvisa(String registroAnvisa) {
		this.registroAnvisa = registroAnvisa;
	}
}
