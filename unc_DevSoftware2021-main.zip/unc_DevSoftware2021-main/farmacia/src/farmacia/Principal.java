package farmacia;

public class Principal {

	public static void main(String[] args) {
		Farmaceutico f = new Farmaceutico();
		f.setNome("Maria");
		System.out.println(f.getNome());
	}

}
