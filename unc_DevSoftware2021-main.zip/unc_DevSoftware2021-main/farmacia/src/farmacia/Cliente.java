package farmacia;

public class Cliente extends Pessoa {
	/* Attributes */
	private String telefone;
	
	/* Getters */
	public String getTelefone() {
		return telefone;
	}
	
	/* Setters */
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
}
